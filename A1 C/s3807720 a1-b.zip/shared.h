/******************************************************************************
 * Student Name    :
 * RMIT Student ID :
 *
 * Startup code provided by Paul Miller for use in "Programming in C",
 * Assignment 1, study period 4, 2020.
 *****************************************************************************/
#ifndef SHARED_H
#define SHARED_H
typedef enum { FALSE, TRUE } BOOLEAN;
#endif
